#from django.urls import path
#from . import views
from .views import Home, ArticleDetailView
from django.contrib import admin
from django.urls import path, include 

urlpatterns = [
    #path('',views.home,name="home")
    #path('admin/', admin.site.urls,name = 'admin'),
    path('',Home.as_view(),name="home"),
    path('article/<int:pk>',ArticleDetailView.as_view(),name='article-detail'),
    ]